const express = require('express');
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const app = express();

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const telegramToken = '7100183538:AAEv5u4or08tRPIl-COdT3xXAEQoeNA0nRU';
const chatId = '7490447695'; // Your chat ID

app.post('/submitOrder', (req, res) => {
    const order = req.body;

    fs.readFile('orders.json', (err, data) => {
        if (err) throw err;
        let orders = JSON.parse(data);
        orders.push(order);

        fs.writeFile('orders.json', JSON.stringify(orders, null, 2), (err) => {
            if (err) throw err;
            console.log('Order saved!');

            // Send a Telegram message
            const message = `New Order! \nProduct: ${order.productName}\nQuantity: ${order.quantity}\nCustomer: ${order.name}\nTip: ${order.tip}\nCoupon-code: ${order.coupon}\nSpecial-Request: ${order.specialRequests}`;
            axios.post(`https://api.telegram.org/bot${telegramToken}/sendMessage`, {
                chat_id: chatId,
                text: message
            }).then(response => {
                console.log('Message sent:', response.data);
                res.sendStatus(200);
            }).catch(error => {
                console.error('Error sending message:', error);
                res.sendStatus(500);
            });
        });
    });
});

app.post('/removeOrder', (req, res) => {
    const index = req.body.index;

    fs.readFile('orders.json', (err, data) => {
        if (err) throw err;
        let orders = JSON.parse(data);
        if (index > -1 && index < orders.length) {
            orders.splice(index, 1);

            fs.writeFile('orders.json', JSON.stringify(orders, null, 2), (err) => {
                if (err) throw err;
                console.log('Order removed!');
                res.sendStatus(200);
            });
        } else {
            res.sendStatus(400);
        }
    });
});

app.get('/getOrders', (req, res) => {
    fs.readFile('orders.json', (err, data) => {
        if (err) throw err;
        let orders = JSON.parse(data);
        res.json(orders);
    });
});

app.listen(80, () => {
    console.log('Server is running on port 80');
});
